#!/bin/sh
# check parameter
if [ $2 ]; then
	echo "odoo-start.sh can only get 1 parameter"
	echo "odoo-start.sh need 1 parameter like 'openerp_server.conf'"
	echo "that was located in 'odoo_conf' folder inside odoo source folder"
	echo "e.g: /home/user_name/odoo/odoo_conf/openerp_server.conf"
	exit 1
fi

# Better OS/400 detection: see Bugzilla 31132
os400=false
case "`uname`" in
OS400*) os400=true;;
esac

# set parameter
loc=$(pwd)					# store current directory name
exe_file=odoo.py			# store exe file name
pid_file=my-odoo.pid		# store process id
cfg_file=$loc/odoo_conf		# store configuration file name
last_cfg=server.cfg			# store last used configuration file name, used by odoo-restart.sh

# check configuration file exists
if [ $1 ]; then
	cfg_used=$1
	cfg_file=$cfg_file/$cfg_used
else
	cfg_used=openerp_server.conf
	cfg_file=$cfg_file/$cfg_used
fi
if [ ! -f "$cfg_file" ]; then
	echo "Cannot found $cfg_file"
	echo "No such file or directory"
	exit 1
fi

# check configuration
while read line;do
	case $line in
		*db_name*)
			dbname=$line;;
		*db_user*)
			dbuser=$line;;
		*data_dir*)
			datadir=$line;;
	esac
done < $cfg_file
echo "Config file: $cfg_file"

sep="="
# remove space and get value
dbname=$(echo "$dbname" | sed 's/  *//g')
dbname=$(echo $dbname | grep -o "$sep.*") # get the value start from '='
dbname=$(echo "$dbname"| sed -r 's/^.{1}//') # remove '='

dbuser=$(echo "$dbuser" | sed 's/  *//g')
dbuser=$(echo $dbuser | grep -o "$sep.*") # get the value start from '='
dbuser=$(echo "$dbuser"| sed -r 's/^.{1}//') # remove '='

datadir=$(echo "$datadir" | sed 's/  *//g')
datadir=$(echo $datadir | grep -o "$sep.*") # get the value start from '='
datadir=$(echo "$datadir"| sed -r 's/^.{1}//') # remove '='

# check data_dir
if [ -d $datadir ]; then
	echo "Data_dir: $datadir found."
else
	echo "Data_dir: $datadir not found.\nCreating now..."
	mkdir $datadir
	rtv=$?
	sleep 1
	if [ $rtv = 0 ]; then
		echo "Data_dir: $datadir has been created."
	else
		echo "Cannot create data_dir: $datadir"
		exit 1
	fi
fi

# check DB User exists
psql -d postgres -U $dbuser -qw -c "SELECT 1 FROM pg_roles WHERE rolname='$dbuser';">/dev/null 2>&1
rtv=$?
if [ $rtv = 0 ]; then
	echo "DB user $dbuser Exists."
else
	echo "DB user $dbuser Not Found."
	exit 1
fi

# check DB exists and create if not exists
psql -lqt | cut -d \| -f 1 | grep -qw $dbname
rtv=$?
if [ $rtv = 0 ]; then
	echo "DB $dbname Exists."
else
	echo "DB $dbname not found.\nCreating databse '$dbname' with owner '$dbuser' now..."
	psql -d postgres -c "CREATE DATABASE $dbname WITH OWNER=$dbuser">/dev/null 2>&1
	rtv=$?
	sleep 1
	if [ $rtv = 0 ]; then
		echo "Database '$dbname' with owner '$dbuser' has been created."
	else
		echo "Database $dbname was not created."
		exit 1
	fi
fi

# Check that target executable exists
if $os400; then
  # -x will Only work on the os400 if the files are:
  # 1. owned by the user
  # 2. owned by the PRIMARY group of the user
  # this will not work if the user belongs in secondary groups
  eval
else
  if [ ! -x "$loc"/"$exe_file" ]; then
    echo "Cannot find $loc/$exe_file"
    echo "The file is absent or does not have execute permission"
    echo "This file is needed to run this program"
    exit 1
  fi
fi

# execute commands
if [ ! -f "$loc"/"$pid_file" ]; then
	echo "Starting odoo-server..."
	if [ -f "$loc"/"$exe_file" ]; then
		python "$loc/$exe_file" -c $cfg_file -d $dbname --db-filter=$dbname & echo $! >"$loc/$pid_file"
		rtv=$?
		
    	if [ $rtv != 0 ]; then
			if [ -f "$loc"/"$pid_file" ]; then
				rm "$loc"/"$pid_file"
			fi
			if [ -f "$loc/$last_cfg" ]; then
				rm $loc/$last_cfg
			fi
			sleep 1
			echo "Error when starting odoo-server"
			echo "Odoo-server not started."
		else
			echo "$cfg_used" >"$loc/$last_cfg"
			sleep 1
			echo "Odoo-server started."
		fi
	else
		sleep 1
		echo "Cannot found odoo.py"
		echo "Odoo-server not started."
		exit 1
	fi
else
	read pid < "$loc"/"$pid_file"
	ps -p $pid > /dev/null
	rtv=$?
	if [ $rtv -eq 0 ]; then
    	echo "Odoo-server is currently running, not executing twice, exiting now..."
    	exit 1
	else
		rm "$loc"/"$pid_file"
		if [ -f "$loc/$last_cfg" ]; then
			rm $loc/$last_cfg
		fi
		sleep 1
		echo "Odoo-server is not running."
	fi
fi

exit 0
