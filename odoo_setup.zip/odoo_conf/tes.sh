#!/bin/sh
loc=$(pwd)
cfg_file=$loc/openerp_server.conf

if [ ! -f "$cfg_file" ]; then
	echo "Cannot found $cfg_file"
	echo "No such file or directory"
	exit 1
fi

sep="="
while read line;do
	case $line in
		*db_name*)
			dbname=$line
			dbname=$(echo "$dbname" | sed 's/  *//g') # remove space and get value
			dbname=$(echo $dbname | grep -o "$sep.*") # get the value start from '='
			dbname=$(echo "$dbname"| sed -r 's/^.{1}//') # remove '='
		;;
		*db_user*)
			dbuser=$line
			dbuser=$(echo "$dbuser" | sed 's/  *//g') # remove space and get value
			dbuser=$(echo $dbuser | grep -o "$sep.*") # get the value start from '='
			dbuser=$(echo "$dbuser"| sed -r 's/^.{1}//') # remove '='
		;;
		*data_dir*)
			datadir=$line
			datadir=$(echo "$datadir" | sed 's/  *//g') # remove space and get value
			datadir=$(echo $datadir | grep -o "$sep.*") # get the value start from '='
			datadir=$(echo "$datadir"| sed -r 's/^.{1}//') # remove '='
		;;
		*addons_path*)
			addons=$line
			addons=$(echo "$addons" | sed 's/  *//g') # remove space and get value
			addons=$(echo $addons | grep -o "$sep.*") # get the value start from '='
			addons=$(echo "$addons"| sed -r 's/^.{1}//') # remove '='
		;;
	esac
done < $cfg_file
echo "Config file: $cfg_file\n$dbname\n$dbuser\n$datadir\n$addons"
: '
arr=$(echo $addons | tr "," "\n")

addons=
for str in $arr
do
	if echo "$str" | grep -q "addons"; then
    	continue
	else
    	echo "String contains is not true."
		addons=$str
	fi
done

# check data_dir
if [ -d $str ]; then
	echo "Addon Folder: $str \nwas found."
else
	echo "Addon Folder: $str not found.\nCreating now..."
	mkdir $str
	rtv=$?
	sleep 1
	if [ $rtv = 0 ]; then
		echo "Addon Folder: $str has been created."
	else
		echo "Cannot create Addon Folder: $str"
		exit 1
	fi
fi'
