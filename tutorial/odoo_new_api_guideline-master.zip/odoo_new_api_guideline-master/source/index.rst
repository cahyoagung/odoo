.. Odoo new API guideline documentation master file, created by
   sphinx-quickstart on Fri Jun  6 23:41:34 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Odoo new API guideline's
===================================

Overview

.. toctree::
   :maxdepth: 3

   environment
   fields
   decorator
   introspection



Conventions and code update

.. toctree::
   :maxdepth: 3

   conventions
   compatibility
   test

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
